package com.retailsstore.discount;

public interface ProductDiscountPolicy {

	double applyDiscount(double totalAmount);

}
