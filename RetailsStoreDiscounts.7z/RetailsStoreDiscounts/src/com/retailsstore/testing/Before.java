package com.retailsstore.testing;

public @interface Before {

}
