package com.retailsstore.basesclass;

public enum ProductType {

	GROCERY,
	OTHER,

}
