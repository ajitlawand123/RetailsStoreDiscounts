package com.retailsstore.basesclass;

public enum UserType {

	EMPLOYEE,
	AFFILIATE,
	SIMPLE
}
